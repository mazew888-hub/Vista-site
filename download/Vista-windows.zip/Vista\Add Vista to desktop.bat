@echo off
rem Puts a Vista shortcut on this PC's desktop.
powershell -NoProfile -Command "$exe=Join-Path '%~dp0' 'Vista.exe'; $d=[Environment]::GetFolderPath('Desktop'); $s=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $d 'Vista.lnk')); $s.TargetPath=$exe; $s.WorkingDirectory='%~dp0'; $s.IconLocation=$exe+',0'; $s.Save()"
echo Vista is on your desktop.
timeout /t 3 >nul
